"""
qpso_optimizer.py
-------------------
Pipeline stage 3 (QPSO Optimization) — the heart of Q-Routes.

Instead of picking one fixed "best" path like Dijkstra, a swarm of candidate
routes is generated and repeatedly nudged toward better options. Each
particle is a whole candidate route (not a point in space), and "movement"
means swapping a piece of the route for a better alternative. The swarm is
steered toward different goals (fast / short / low-congestion / balanced)
just by changing the fitness weights it's told to optimize for — that's
what produces 5 genuinely different labelled routes from the same engine.

Quantum-inspired behaviour, adapted for a discrete route space:
  - Every particle sometimes "collapses" partway toward the current global
    best route (a crossover-style splice) instead of only ever exploring
    on its own — this mirrors real QPSO's core idea that a particle's next
    position is drawn probabilistically around a shared best-known point
    (mbest), rather than moving along a fixed velocity vector like classic
    PSO.
  - `contraction_expansion` controls how strongly particles are pulled
    toward that shared best route vs. how freely they keep exploring
    alternatives — the same role the contraction-expansion coefficient
    plays in real QPSO.
"""

import random
import time
import logging

import networkx as nx

logger = logging.getLogger("qroutes.qpso_optimizer")

# Configurable QPSO parameters — tune these without rewriting any logic.
DEFAULT_SWARM_SIZE = 20
DEFAULT_ITERATIONS = 40
DEFAULT_CONTRACTION_EXPANSION = 1.2
MAX_RUNTIME_SECONDS = 1.8  # keep every run demo-fast (under ~2s)

# The 5 route types the pitch deck promises, each just a different fitness
# weighting run through the exact same QPSO engine.
ROUTE_CONFIGS = [
    {"label": "Fastest Route",      "weights": {"time": 1.0, "distance": 0.0, "congestion": 0.0}},
    {"label": "Shortest Route",     "weights": {"time": 0.0, "distance": 1.0, "congestion": 0.0}},
    {"label": "Less Traffic Route", "weights": {"time": 0.2, "distance": 0.1, "congestion": 1.0}},
    {"label": "Less Time Route",    "weights": {"time": 0.7, "distance": 0.0, "congestion": 0.6}},
    {"label": "Balanced Route",     "weights": {"time": 0.4, "distance": 0.3, "congestion": 0.3}},
]


# --------------------------------------------------------------------------
# Route-level helpers
# --------------------------------------------------------------------------

def route_stats(graph, route):
    """Total time (minutes), total distance (km) and average congestion
    multiplier for a given route — used both for fitness and for the
    numbers shown on each route card in the UI."""
    total_time = 0.0
    total_distance_m = 0.0
    congestions = []

    for u, v in zip(route[:-1], route[1:]):
        edge_data = min(
            graph.get_edge_data(u, v).values(),
            key=lambda d: d.get("weight_time", float("inf")),
        )
        total_time += edge_data.get("base_time", 0.0) * edge_data.get("congestion_multiplier", 1.0)
        total_distance_m += edge_data.get("length", 0.0)
        congestions.append(edge_data.get("congestion_multiplier", 1.0))

    avg_congestion = sum(congestions) / len(congestions) if congestions else 1.0
    return {
        "time_minutes": total_time,
        "distance_km": total_distance_m / 1000.0,
        "avg_congestion": avg_congestion,
    }


def _congestion_level_label(avg_congestion):
    if avg_congestion < 1.5:
        return "Low"
    if avg_congestion < 2.5:
        return "Medium"
    return "High"


def fitness(graph, route, weights):
    """Weighted-sum fitness: lower is better. Combines time, distance and
    congestion according to whatever this QPSO run is optimizing for."""
    stats = route_stats(graph, route)
    return (
        weights.get("time", 0.0) * stats["time_minutes"]
        + weights.get("distance", 0.0) * stats["distance_km"]
        + weights.get("congestion", 0.0) * stats["avg_congestion"] * stats["distance_km"]
    )


# --------------------------------------------------------------------------
# Swarm generation & perturbation
# --------------------------------------------------------------------------

def _simple_digraph_view(graph):
    """
    nx.shortest_simple_paths() doesn't support MultiDiGraph, so this builds
    a plain DiGraph with one edge per (u, v) — keeping whichever parallel
    edge currently has the lowest weight_time — purely for path-enumeration
    purposes. All fitness/stat calculations still use the real multigraph.
    """
    simple = nx.DiGraph()
    simple.add_nodes_from(graph.nodes(data=True))
    for u, v, data in graph.edges(data=True):
        w = data.get("weight_time", float("inf"))
        if not simple.has_edge(u, v) or w < simple.edges[u, v]["weight_time"]:
            simple.add_edge(u, v, weight_time=w)
    return simple


def _generate_candidate_routes(graph, start_node, end_node, swarm_size):
    """Seeds the swarm using k-shortest-paths; pads with slightly-randomised
    duplicates if the graph doesn't have enough distinct simple paths
    (common on small demo graphs)."""
    candidates = []
    simple_graph = _simple_digraph_view(graph)
    try:
        path_generator = nx.shortest_simple_paths(simple_graph, start_node, end_node, weight="weight_time")
        for i, path in enumerate(path_generator):
            candidates.append(path)
            if len(candidates) >= swarm_size:
                break
    except nx.NetworkXNoPath:
        return []

    if not candidates:
        return []

    # Pad the swarm out to swarm_size by reusing existing candidates —
    # they'll still get perturbed differently during optimization.
    while len(candidates) < swarm_size:
        candidates.append(random.choice(candidates))

    return candidates


def _perturb_route(graph, route, global_best_route, beta):
    """
    Produces one new candidate route from an existing one, either by:
      (a) "quantum collapse" toward the global best — splice in a segment
          from the current best-known route (probability grows with beta),
          or
      (b) local exploration — reroute a random sub-section of the current
          route to a fresh alternative path.
    Falls back to returning the original route unchanged if no valid
    perturbation is found.
    """
    if len(route) < 3:
        return route

    collapse_probability = min(0.85, beta / 2.0)

    if random.random() < collapse_probability and len(global_best_route) >= 3:
        # Try to splice a chunk of the global best route into this one at a
        # node they both pass through.
        shared_nodes = set(route) & set(global_best_route)
        shared_nodes.discard(route[0])
        shared_nodes.discard(route[-1])
        if shared_nodes:
            pivot = random.choice(list(shared_nodes))
            gi = global_best_route.index(pivot)
            ri = route.index(pivot)
            spliced = route[:ri] + global_best_route[gi:]
            if _is_valid_route(graph, spliced):
                return spliced

    # Local exploration: reroute a random sub-section to an alternative path.
    i = random.randint(0, len(route) - 2)
    j = random.randint(i + 1, len(route) - 1)
    sub_start, sub_end = route[i], route[j]
    try:
        alt_subpath = nx.shortest_path(
            graph, sub_start, sub_end,
            weight=lambda u, v, d: min(e.get("weight_time", 1.0) for e in d.values()) * random.uniform(0.7, 1.6),
        )
    except nx.NetworkXNoPath:
        return route

    new_route = route[:i] + alt_subpath + route[j + 1:]
    return new_route if _is_valid_route(graph, new_route) else route


def _is_valid_route(graph, route):
    return all(graph.has_edge(u, v) for u, v in zip(route[:-1], route[1:]))


# --------------------------------------------------------------------------
# Step 7 — The QPSO core
# --------------------------------------------------------------------------

def run_qpso(graph, start_node, end_node, weights,
             swarm_size=DEFAULT_SWARM_SIZE,
             iterations=DEFAULT_ITERATIONS,
             contraction_expansion=DEFAULT_CONTRACTION_EXPANSION):
    """
    Quantum-inspired Particle Swarm Optimization over candidate routes.

    Args:
        graph: NetworkX graph with weight_time already computed on edges.
        start_node, end_node: node IDs to route between.
        weights: dict like {"time": 1.0, "distance": 0.0, "congestion": 0.0}
                 controlling what this run optimizes for.
        swarm_size, iterations, contraction_expansion: tunable QPSO knobs.

    Returns:
        dict(route=[...], cost=float, computation_time_ms=float)
    """
    start_clock = time.perf_counter()

    particles = _generate_candidate_routes(graph, start_node, end_node, swarm_size)
    if not particles:
        raise nx.NetworkXNoPath(f"No path between {start_node} and {end_node}")

    fitnesses = [fitness(graph, r, weights) for r in particles]
    best_idx = min(range(len(particles)), key=lambda i: fitnesses[i])
    global_best_route = particles[best_idx]
    global_best_fitness = fitnesses[best_idx]

    for _ in range(iterations):
        if time.perf_counter() - start_clock > MAX_RUNTIME_SECONDS:
            logger.info("QPSO stopped early at runtime budget.")
            break

        for i, route in enumerate(particles):
            candidate = _perturb_route(graph, route, global_best_route, contraction_expansion)
            candidate_fitness = fitness(graph, candidate, weights)

            # Accept if better, or occasionally accept a worse move so the
            # swarm keeps exploring instead of collapsing too early —
            # exploration probability shrinks as contraction_expansion grows.
            if candidate_fitness < fitnesses[i] or random.random() < (0.15 / contraction_expansion):
                particles[i] = candidate
                fitnesses[i] = candidate_fitness

        iter_best_idx = min(range(len(particles)), key=lambda i: fitnesses[i])
        if fitnesses[iter_best_idx] < global_best_fitness:
            global_best_fitness = fitnesses[iter_best_idx]
            global_best_route = particles[iter_best_idx]

    elapsed_ms = (time.perf_counter() - start_clock) * 1000.0
    return {
        "route": global_best_route,
        "cost": global_best_fitness,
        "computation_time_ms": elapsed_ms,
    }


# --------------------------------------------------------------------------
# Step 8 — Generate the 5 labelled route options
# --------------------------------------------------------------------------

def get_five_routes(graph, start_node, end_node):
    """
    Runs QPSO 5 times with 5 different objective weightings and returns a
    list of 5 dicts, each ready to hand straight to the frontend / API
    response: label, route (node IDs), cost, time_minutes, distance_km,
    congestion_level.
    """
    results = []
    for config in ROUTE_CONFIGS:
        outcome = run_qpso(graph, start_node, end_node, config["weights"])
        stats = route_stats(graph, outcome["route"])
        results.append({
            "label": config["label"],
            "route": outcome["route"],
            "cost": outcome["cost"],
            "time_minutes": round(stats["time_minutes"], 2),
            "distance_km": round(stats["distance_km"], 3),
            "congestion_level": _congestion_level_label(stats["avg_congestion"]),
            "computation_time_ms": round(outcome["computation_time_ms"], 2),
        })
    return results


if __name__ == "__main__":
    # Tiny 8-node test graph so this file can be sanity-checked on its own.
    g = nx.MultiDiGraph()
    edges = [
        (0, 1, 100), (1, 2, 100), (2, 3, 100), (3, 7, 150),
        (0, 4, 120), (4, 5, 120), (5, 6, 120), (6, 7, 100),
        (1, 5, 80), (2, 6, 90),
    ]
    for u, v, length in edges:
        g.add_edge(u, v, key=0, length=length, base_time=length / 500 * 60,
                   congestion_multiplier=1.0, weight_time=length / 500 * 60)
        g.add_edge(v, u, key=0, length=length, base_time=length / 500 * 60,
                   congestion_multiplier=1.0, weight_time=length / 500 * 60)

    result = run_qpso(g, 0, 7, weights={"time": 1.0, "distance": 0.0, "congestion": 0.0})
    print("Best route:", result["route"])
    print("Cost:", round(result["cost"], 3))
    print("Computation time (ms):", round(result["computation_time_ms"], 3))
