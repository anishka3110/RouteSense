"""
baseline_algorithms.py
-----------------------
Pipeline stage 3 & 4 (benchmark side) — classic shortest-path algorithms
used to prove QPSO is actually competitive, not just different.

Both functions return a dict with:
  route                -> list of node IDs
  cost                  -> total weight_time along the path
  computation_time_ms   -> how long the search took
"""

import math
import time

import networkx as nx


def _euclidean_heuristic(graph):
    """Builds an A* heuristic function using each node's x/y (lon/lat)
    coordinates — a straight-line distance estimate that never
    over-estimates the real travel time, which is what A* needs to stay
    optimal."""

    def heuristic(u, v):
        ux, uy = graph.nodes[u]["x"], graph.nodes[u]["y"]
        vx, vy = graph.nodes[v]["x"], graph.nodes[v]["y"]
        # Straight-line degrees -> a rough metres estimate, then to minutes
        # using the fastest assumed road speed, so it stays "admissible".
        dist_deg = math.hypot(ux - vx, uy - vy)
        dist_m = dist_deg * 111_320
        return (dist_m / 1000.0) / 80.0 * 60.0  # minutes, assuming 80 km/h

    return heuristic


def dijkstra_route(graph, start_node, end_node):
    """
    'What a normal maps app would suggest' — the plain shortest path by
    total weight_time (distance + time + current congestion combined),
    using NetworkX's built-in Dijkstra implementation.
    """
    start = time.perf_counter()
    route = nx.shortest_path(graph, start_node, end_node,
                              weight="weight_time", method="dijkstra")
    cost = nx.path_weight(graph, route, weight="weight_time")
    elapsed_ms = (time.perf_counter() - start) * 1000.0
    return {"route": route, "cost": cost, "computation_time_ms": elapsed_ms}


def astar_route(graph, start_node, end_node):
    """
    Same goal as Dijkstra, but guided by a straight-line-distance heuristic
    so it explores fewer nodes — usually faster on larger graphs while
    still finding the optimal path.
    """
    start = time.perf_counter()
    heuristic = _euclidean_heuristic(graph)
    route = nx.astar_path(graph, start_node, end_node,
                           heuristic=heuristic, weight="weight_time")
    cost = nx.path_weight(graph, route, weight="weight_time")
    elapsed_ms = (time.perf_counter() - start) * 1000.0
    return {"route": route, "cost": cost, "computation_time_ms": elapsed_ms}


if __name__ == "__main__":
    from graph_builder import download_road_network, prepare_graph_weights

    g = prepare_graph_weights(download_road_network(12.9716, 77.5946))
    nodes = list(g.nodes())
    start_node, end_node = nodes[0], nodes[-1]

    d = dijkstra_route(g, start_node, end_node)
    a = astar_route(g, start_node, end_node)
    print("Dijkstra:", len(d["route"]), "nodes, cost", round(d["cost"], 2),
          "in", round(d["computation_time_ms"], 3), "ms")
    print("A*:      ", len(a["route"]), "nodes, cost", round(a["cost"], 2),
          "in", round(a["computation_time_ms"], 3), "ms")
