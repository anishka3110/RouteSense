"""
test_end_to_end.py
--------------------
Proves the whole non-web backend pipeline works together on a small, fast
test graph, before wiring up React/Leaflet. Run with: python test_end_to_end.py
"""

import networkx as nx

from graph_builder import prepare_graph_weights, filter_graph_for_vehicle
from qpso_optimizer import get_five_routes, ROUTE_CONFIGS
from baseline_algorithms import dijkstra_route, astar_route
from load_balancer import pick_best_route, route_load_counter, session_assignments
import traffic_simulator


def build_test_graph(n=20, seed=42):
    """A small random geometric graph — fast, but still has multiple
    real alternative paths between most node pairs."""
    import random
    random.seed(seed)

    pos_graph = nx.random_geometric_graph(n, radius=0.35, seed=seed)
    graph = nx.MultiDiGraph()
    for node, data in pos_graph.nodes(data=True):
        x, y = data["pos"]
        graph.add_node(node, x=x, y=y)

    highway_choices = ["residential", "residential", "tertiary", "footway"]
    for u, v in pos_graph.edges():
        length = random.uniform(80, 300)
        highway = random.choice(highway_choices)
        width = round(random.uniform(2.5, 8.0), 1)
        for a, b in [(u, v), (v, u)]:
            graph.add_edge(a, b, key=0, length=length, highway=highway,
                            width=width, congestion_multiplier=1.0)
    return graph


def check(label, condition):
    status = "[OK]" if condition else "[FAIL]"
    print(f"{status} {label}")
    return condition


def main():
    all_ok = True

    graph = build_test_graph()
    graph = prepare_graph_weights(graph)
    all_ok &= check("Test graph built and weighted", graph.number_of_edges() > 0)

    nodes = list(graph.nodes())
    # Pick the FARTHEST reachable node from node 0 (by hop count) so the
    # route actually has several edges and room for genuinely different
    # 5-route options — a 1-edge hop wouldn't show much.
    lengths = nx.single_source_shortest_path_length(nx.Graph(graph), nodes[0])
    start_node = nodes[0]
    end_node = max(lengths, key=lengths.get)
    all_ok &= check("Found a connected, multi-hop start/end pair",
                     lengths[end_node] >= 2)

    # --- 5-route generation -------------------------------------------------
    five_routes = get_five_routes(graph, start_node, end_node)
    labels = [r["label"] for r in five_routes]
    all_ok &= check("5 route labels generated", len(five_routes) == 5)
    all_ok &= check("Labels match expected set",
                     set(labels) == {c["label"] for c in ROUTE_CONFIGS})

    print("\n  Route".ljust(22), "Time(min)", "Dist(km)", "Congestion")
    for r in five_routes:
        print(f"  {r['label']:<20}{r['time_minutes']:>9.2f}{r['distance_km']:>10.3f}   {r['congestion_level']}")

    # --- baselines ------------------------------------------------------------
    dijkstra = dijkstra_route(graph, start_node, end_node)
    astar = astar_route(graph, start_node, end_node)
    all_ok &= check("Dijkstra found a route", len(dijkstra["route"]) >= 2)
    all_ok &= check("A* found a route", len(astar["route"]) >= 2)
    print(f"\n  Dijkstra cost={dijkstra['cost']:.2f} ({dijkstra['computation_time_ms']:.2f} ms)")
    print(f"  A*       cost={astar['cost']:.2f} ({astar['computation_time_ms']:.2f} ms)")

    # --- multi-session load balancing -----------------------------------------
    session_assignments.clear()
    route_load_counter.clear()
    assigned = []
    for i in range(4):
        chosen, load_snapshot = pick_best_route(f"demo-tab-{i}", start_node, end_node, five_routes)
        assigned.append(chosen["label"])
    all_ok &= check("4 simulated sessions spread across more than 1 route",
                     len(set(assigned)) > 1)
    print("\n  4 simulated sessions assigned to:", assigned)

    # --- traffic change actually changes route costs ---------------------------
    # Randomly simulated traffic might not happen to land on THIS route's
    # edges, so to make the check deterministic we directly jam the first
    # edge of the current best ("Fastest") route and confirm the system
    # reacts to it — this is exactly what apply_dynamic_traffic() does,
    # just targeted instead of random, so the test is reliable.
    from graph_builder import refresh_graph_weights

    before_costs = {r["label"]: r["cost"] for r in five_routes}
    fastest_route = next(r["route"] for r in five_routes if r["label"] == "Fastest Route")
    u, v = fastest_route[0], fastest_route[1]
    for edge_data in graph.get_edge_data(u, v).values():
        edge_data["congestion_multiplier"] = 4.0
    refresh_graph_weights(graph)

    after_routes = get_five_routes(graph, start_node, end_node)
    after_costs = {r["label"]: r["cost"] for r in after_routes}
    all_ok &= check("Route costs changed after simulated traffic",
                     before_costs != after_costs)

    # --- vehicle filtering -------------------------------------------------
    walk_graph = filter_graph_for_vehicle(graph, "walking")
    bus_graph = filter_graph_for_vehicle(graph, "bus")
    all_ok &= check("Bus graph has fewer or equal edges than walking graph",
                     bus_graph.number_of_edges() <= walk_graph.number_of_edges())

    print("\n" + ("ALL CHECKS PASSED" if all_ok else "SOME CHECKS FAILED"))
    return all_ok


if __name__ == "__main__":
    main()
