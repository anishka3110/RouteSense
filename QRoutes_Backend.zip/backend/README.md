# Q-Routes Backend

Quantum-Inspired Dynamic Traffic Intelligence System — **backend only**
(FastAPI + NetworkX + QPSO). Built for Smart India Hackathon 2026,
Problem Statement 26137, Team OptiMinds.

No login, no signup, no user accounts anywhere in this project. Every
"user" is just an anonymous browser tab identified by a random
`session_id` generated client-side.

## Architecture

| Module | Responsibility | Pipeline stage |
|---|---|---|
| `graph_builder.py` | Downloads/loads the OSM road network (with an automatic simulated-graph fallback if OSM is unreachable), builds the weighted graph, filters it per vehicle type. | 1, 2 |
| `traffic_simulator.py` | Randomly congests/clears edges on a timer to simulate live traffic. | 1 |
| `qpso_optimizer.py` | The Quantum-inspired Particle Swarm Optimization core; generates the 5 labelled route options. | 3 |
| `baseline_algorithms.py` | Dijkstra and A* benchmarks, compared against QPSO. | 3, 4 |
| `load_balancer.py` | Tracks active sessions per route and spreads new sessions across less-loaded routes. | 5 |
| `api_routes.py` | FastAPI endpoints + the WebSocket that push everything to the frontend. | 6 |
| `database.py` | PostgreSQL/PostGIS persistence for road/traffic snapshots, with automatic SQLite fallback. | — |
| `schemas.py` | Pydantic request/response models. | — |
| `main.py` | App entry point; wires startup (graph load, traffic timer, reroute watcher). | — |

This mirrors the 6-stage pipeline from the pitch deck: **Traffic & Road
Data → Graph Modeling → QPSO Optimization → Route Evaluation → Traffic
Load Balancing → Optimized Output.**

## How QPSO and the 5 routes work

`qpso_optimizer.run_qpso()` treats each candidate **route** (not a point in
space) as one particle. A swarm of candidate routes is seeded using
k-shortest-paths, then repeatedly perturbed: with a probability controlled
by the `contraction_expansion` coefficient, a particle "collapses" toward
the current best-known route (splicing in a shared segment); otherwise it
explores a fresh alternative for a random sub-section of itself. This
mirrors real QPSO's core idea — particles are drawn probabilistically
toward a shared best point rather than following a fixed velocity vector
like classic PSO — adapted to a discrete route space.

`get_five_routes()` calls `run_qpso()` five times with five different
fitness weightings (time / distance / congestion mix), producing:

1. **Fastest Route** — pure travel time
2. **Shortest Route** — pure distance
3. **Less Traffic Route** — heavily weighted against congestion
4. **Less Time Route** — time + congestion-variance penalty
5. **Balanced Route** — a mix of all three

Each route reports estimated time, distance, and a Low/Medium/High
congestion label for the frontend's route cards.

## How the no-login, multi-session load balancing works

Each browser tab sends its own random `session_id` with every `/get-routes`
call — nothing is stored per-account, only per-session, and only in
memory (`load_balancer.py`). When 4 tabs request the same source and
destination:

1. All 4 get the same 5 QPSO-generated routes.
2. `load_balancer.pick_best_route()` scores each route as
   `cost * (1 + 0.35 * sessions_already_on_that_route)`.
3. Because each assignment updates the load counter immediately, the next
   tab's request sees a different "cheapest" option — so the 4 tabs
   naturally spread across different routes instead of piling onto one.
4. `/ws/live-updates` pushes the live load snapshot to every connected
   tab so a "Live Traffic Load" panel can update in real time.

## Real-time congestion alerts

A background task (`api_routes.check_for_reroutes`) runs every 6 seconds,
checks each active session for heavy congestion within ~1 km ahead on its
current route (simulated position, since there's no real GPS input for a
hackathon demo), and — if found — reruns QPSO and pushes a `traffic_alert`
with the new route over the WebSocket.

## Running it locally

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python main.py                  # or: uvicorn main:app --reload
```

Open `http://localhost:8000/docs` to try `/get-routes` and
`/compare-algorithms` interactively, or `http://localhost:8000/ping` to
confirm the server is up.

Before your live demo, edit `DEMO_LAT` / `DEMO_LNG` / `DEMO_AREA_NAME` at
the top of `main.py` to your chosen neighbourhood's coordinates.

### Running without internet / without PostgreSQL

- No internet or OSM is unreachable → `graph_builder.download_road_network()`
  automatically falls back to a simulated grid graph, so the server still
  starts and serves routes.
- No `DATABASE_URL` environment variable set → `database.py` automatically
  falls back to a local `qroutes.db` SQLite file. Set `DATABASE_URL` to a
  PostgreSQL+PostGIS connection string to use it in production.

### Running the test suite

```bash
python test_end_to_end.py
```

This builds a small, fast test graph and checks: 5 distinct routes are
generated, Dijkstra/A* both find valid routes, 4 simulated sessions spread
across more than one route, route costs actually change after simulated
congestion, and vehicle filtering removes the right edges.

## Swapping in real traffic data later

Replace calls to `traffic_simulator.apply_dynamic_traffic()` with a call
to a real traffic API (e.g. TomTom, Google Roads, or a city's open traffic
feed) that sets each edge's `congestion_multiplier` from real data, then
calls `graph_builder.refresh_graph_weights(graph)` — every other module
(QPSO, baselines, load balancer, alerts) already reacts to whatever is in
`congestion_multiplier` without needing any other change.

## API summary

| Endpoint | Method | Purpose |
|---|---|---|
| `/ping` | GET | Health check |
| `/get-routes` | POST | Get the 5 routes + this session's assigned route + live load |
| `/compare-algorithms` | GET | QPSO vs Dijkstra vs A* on the same request |
| `/ws/live-updates` | WebSocket | Live route-load + traffic-alert push |
