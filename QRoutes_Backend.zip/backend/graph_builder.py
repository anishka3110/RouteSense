"""
graph_builder.py
-----------------
Pipeline stage 1 & 2 (Traffic & Road Data / Graph Modeling).

Responsible for:
  - Downloading the real road network for the demo area from OpenStreetMap
    (via OSMnx), with an automatic fallback to a simulated grid graph if
    the internet / OSM server isn't available, so the app never crashes.
  - Making sure every edge in the graph carries the three numbers the rest
    of the system needs: distance ('length'), free-flow travel time
    ('base_time'), and current congestion ('congestion_multiplier') which
    combine into 'weight_time' — the number all route-finding algorithms
    actually search on.
  - Filtering the graph down to only the roads a given vehicle type is
    allowed to use (car / bus / bike / cycle / walking).

Node attributes used elsewhere: 'x' (longitude), 'y' (latitude).
Edge attributes used elsewhere: 'length', 'base_time', 'congestion_multiplier',
'weight_time', 'highway', 'width'.
"""

import math
import random
import logging

import networkx as nx

logger = logging.getLogger("qroutes.graph_builder")
logging.basicConfig(level=logging.INFO)

# Approximate free-flow speeds (km/h) per road type — used to turn a road's
# length into a "base_time" (how long it takes with zero traffic).
HIGHWAY_SPEED_KMH = {
    "motorway": 80,
    "primary": 50,
    "secondary": 40,
    "tertiary": 35,
    "residential": 25,
    "living_street": 15,
    "cycleway": 18,
    "footway": 5,
    "path": 5,
    "unclassified": 30,
}

DEFAULT_SPEED_KMH = 30


def _speed_for_highway(highway_tag):
    """OSM 'highway' tags can be a string or a list of strings; normalise it."""
    if isinstance(highway_tag, list):
        highway_tag = highway_tag[0] if highway_tag else None
    return HIGHWAY_SPEED_KMH.get(highway_tag, DEFAULT_SPEED_KMH)


# --------------------------------------------------------------------------
# Step 3 — Download the real road network (with a safe fallback)
# --------------------------------------------------------------------------

def _build_fallback_graph(lat, lng, grid_size=10, spacing_m=120):
    """
    Builds a small simulated street grid centred on (lat, lng) when OSM data
    can't be downloaded (no internet, OSM server down, timeout, etc).

    This keeps Q-Routes fully demo-able offline: it produces a graph with the
    same shape/attributes a real OSMnx graph would have, just laid out as a
    regular grid instead of real streets.
    """
    logger.warning(
        "Falling back to a simulated %sx%s grid graph centred at (%.5f, %.5f) "
        "— OSM data was not available.", grid_size, grid_size, lat, lng
    )

    raw = nx.grid_2d_graph(grid_size, grid_size)
    graph = nx.MultiDiGraph()

    # Roughly convert metres to degrees so the fake grid sits near the real
    # coordinates the user picked (good enough for a demo, not for real GPS).
    meters_per_deg_lat = 111_320
    meters_per_deg_lng = 111_320 * max(math.cos(math.radians(lat)), 0.01)

    node_id_map = {}
    for idx, (gx, gy) in enumerate(raw.nodes()):
        node_lat = lat + (gy - grid_size / 2) * spacing_m / meters_per_deg_lat
        node_lng = lng + (gx - grid_size / 2) * spacing_m / meters_per_deg_lng
        node_id_map[(gx, gy)] = idx
        graph.add_node(idx, x=node_lng, y=node_lat)

    highway_choices = ["residential", "residential", "residential", "tertiary", "footway"]
    for (u, v) in raw.edges():
        uid, vid = node_id_map[u], node_id_map[v]
        length = spacing_m * random.uniform(0.85, 1.25)
        highway = random.choice(highway_choices)
        width = round(random.uniform(2.5, 8.0), 1)
        # Undirected demo grid -> add both directions since routing code
        # assumes a directed MultiDiGraph like OSMnx produces.
        for a, b in [(uid, vid), (vid, uid)]:
            graph.add_edge(a, b, key=0, length=length, highway=highway,
                            width=width, congestion_multiplier=1.0)

    return graph


def download_road_network(lat, lng, radius_m=1200):
    """
    Downloads the driving + walking road network within radius_m metres of
    (lat, lng) using OSMnx, saves it to road_network.graphml, and returns
    the graph. Falls back to a simulated grid graph if OSM is unreachable.
    """
    try:
        import osmnx as ox  # imported lazily so this module still loads
                             # (and the fallback still works) even if osmnx
                             # isn't installed yet in this environment.

        graph = ox.graph_from_point((lat, lng), dist=radius_m, network_type="all")
        graph = nx.MultiDiGraph(graph)  # ensure consistent type

        for _, _, _, data in graph.edges(keys=True, data=True):
            data.setdefault("congestion_multiplier", 1.0)

        ox.save_graphml(graph, filepath="road_network.graphml")
        logger.info("Downloaded real OSM road network: %s nodes, %s edges.",
                    graph.number_of_nodes(), graph.number_of_edges())
        return graph

    except Exception as exc:  # noqa: BLE001 — any failure => graceful fallback
        logger.warning("OSM download failed (%s: %s). Using fallback graph.",
                        type(exc).__name__, exc)
        graph = _build_fallback_graph(lat, lng)
        try:
            nx.write_graphml(graph, "road_network.graphml")
        except Exception:  # pragma: no cover - saving the fallback is best-effort
            pass
        logger.info("Fallback graph ready: %s nodes, %s edges.",
                    graph.number_of_nodes(), graph.number_of_edges())
        return graph


def load_cached_graph(path="road_network.graphml"):
    """Loads a previously-saved graph from disk, if one exists."""
    graph = nx.read_graphml(path, node_type=int)
    return nx.MultiDiGraph(graph)


# --------------------------------------------------------------------------
# Step 4 — Dynamic weighted graph model
# --------------------------------------------------------------------------

def prepare_graph_weights(graph):
    """
    Makes sure every edge has 'length', 'base_time' and 'congestion_multiplier',
    then computes the combined 'weight_time' used for all route searches.
    Call this once after building/loading a graph.
    """
    for u, v, key, data in graph.edges(keys=True, data=True):
        length = data.get("length")
        if length is None:
            length = random.uniform(50, 400)
        data["length"] = float(length)

        speed_kmh = _speed_for_highway(data.get("highway"))
        base_time_hours = data["length"] / 1000.0 / speed_kmh
        data["base_time"] = base_time_hours * 60.0  # minutes

        data.setdefault("congestion_multiplier", 1.0)

    refresh_graph_weights(graph)
    return graph


def refresh_graph_weights(graph):
    """
    Recomputes 'weight_time' on every edge from the current
    congestion_multiplier values. Call this any time congestion changes
    instead of rebuilding the whole graph — it's cheap and keeps every
    downstream algorithm (Dijkstra, A*, QPSO) using fresh numbers.
    """
    for u, v, key, data in graph.edges(keys=True, data=True):
        base_time = data.get("base_time", 1.0)
        congestion = data.get("congestion_multiplier", 1.0)
        data["weight_time"] = base_time * congestion
    return graph


# --------------------------------------------------------------------------
# Step 9 — Filter the graph by vehicle type
# --------------------------------------------------------------------------

# Which OSM 'highway' tags each vehicle type is NOT allowed to use.
_VEHICLE_BLOCKED_HIGHWAYS = {
    "car": {"footway", "path", "cycleway", "steps", "pedestrian"},
    "bus": {"footway", "path", "cycleway", "steps", "pedestrian"},
    "bike": {"footway", "path", "steps", "pedestrian"},
    "cycle": {"steps", "pedestrian"},
    "walking": {"motorway"},
}

_BUS_MIN_WIDTH_M = 3.5


def filter_graph_for_vehicle(graph, vehicle_type):
    """
    Returns a COPY of the graph with edges removed that the given
    vehicle_type isn't actually allowed to use, so suggested routes stay
    realistic (e.g. a bus should never be routed down a footpath).

    If tag/width data is missing on an edge, it's assumed accessible —
    we don't want to over-filter and accidentally disconnect the graph.
    """
    vehicle_type = vehicle_type.lower()
    blocked = _VEHICLE_BLOCKED_HIGHWAYS.get(vehicle_type, set())

    filtered = graph.copy()
    edges_to_remove = []

    for u, v, key, data in filtered.edges(keys=True, data=True):
        highway = data.get("highway")
        if isinstance(highway, list):
            highway = highway[0] if highway else None

        if highway is not None and highway in blocked:
            edges_to_remove.append((u, v, key))
            continue

        if vehicle_type == "bus":
            width = data.get("width")
            if width is not None:
                try:
                    if float(width) < _BUS_MIN_WIDTH_M:
                        edges_to_remove.append((u, v, key))
                except (TypeError, ValueError):
                    pass  # unparsable width -> assume accessible

    filtered.remove_edges_from(edges_to_remove)
    logger.info("Filtered graph for vehicle_type=%s: removed %s of %s edges.",
                vehicle_type, len(edges_to_remove), graph.number_of_edges())
    return filtered


if __name__ == "__main__":
    # Quick manual smoke test using the fallback path (no internet needed).
    g = download_road_network(lat=12.9716, lng=77.5946, radius_m=1000)
    g = prepare_graph_weights(g)
    print("Nodes:", g.number_of_nodes(), "Edges:", g.number_of_edges())
    sample_edge = next(iter(g.edges(keys=True, data=True)))
    print("Sample edge:", sample_edge)

    walk_graph = filter_graph_for_vehicle(g, "walking")
    bus_graph = filter_graph_for_vehicle(g, "bus")
    print("Walking edges:", walk_graph.number_of_edges(),
          "| Bus edges:", bus_graph.number_of_edges())
