"""
main.py
--------
Q-Routes backend entry point.

- Creates the FastAPI app, opens CORS to everyone (this is a hackathon
  demo — no auth, no accounts, so there's nothing sensitive to protect
  behind CORS).
- On startup: builds/loads the road network for the demo area, starts the
  traffic simulator timer, starts the background reroute-checker, and logs
  a snapshot of the initial road network to the database.
- No login, no signup, no user table anywhere in this project — every
  "user" is just an anonymous browser tab identified by a client-generated
  session_id.

Run with:  python main.py
       or: uvicorn main:app --reload
"""

import asyncio
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

import graph_builder
import traffic_simulator
import database
import api_routes
from api_routes import router as api_router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("qroutes.main")

# --------------------------------------------------------------------------
# Demo area — pick one small, real Indian city neighbourhood (1-2km across)
# before your demo. These defaults are a small area in Bengaluru.
# --------------------------------------------------------------------------
DEMO_AREA_NAME = "Bengaluru demo area"
DEMO_LAT = 12.9716
DEMO_LNG = 77.5946
DEMO_RADIUS_M = 1200
TRAFFIC_UPDATE_INTERVAL_SECONDS = 15

app = FastAPI(title="Q-Routes Backend", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router)

_traffic_timer = None


@app.get("/ping")
def ping():
    return {"status": "ok"}


@app.on_event("startup")
async def on_startup():
    global _traffic_timer

    logger.info("Building road network for %s ...", DEMO_AREA_NAME)
    graph = graph_builder.download_road_network(DEMO_LAT, DEMO_LNG, DEMO_RADIUS_M)
    graph = graph_builder.prepare_graph_weights(graph)
    api_routes.STATE["graph"] = graph

    try:
        database.save_road_network_snapshot(
            DEMO_AREA_NAME, graph.number_of_nodes(), graph.number_of_edges()
        )
    except Exception:  # noqa: BLE001
        logger.exception("Could not save initial road network snapshot.")

    # Traffic timer runs on a background thread and calls back into asyncio
    # via run_coroutine_threadsafe so it can still trigger a WebSocket
    # broadcast from a plain thread callback.
    loop = asyncio.get_event_loop()

    def _on_traffic_update(congested_edges):
        api_routes.on_traffic_update(congested_edges)
        asyncio.run_coroutine_threadsafe(
            api_routes.broadcast_update({
                "type": "traffic_alert",
                "message": f"{len(congested_edges)} road segments just changed congestion.",
            }),
            loop,
        )

    _traffic_timer = traffic_simulator.start_traffic_timer(
        graph, interval_seconds=TRAFFIC_UPDATE_INTERVAL_SECONDS, on_update=_on_traffic_update
    )

    asyncio.create_task(api_routes.check_for_reroutes())

    logger.info("Q-Routes backend ready: %s nodes, %s edges.",
                graph.number_of_nodes(), graph.number_of_edges())


@app.on_event("shutdown")
def on_shutdown():
    if _traffic_timer:
        _traffic_timer.stop()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000)
