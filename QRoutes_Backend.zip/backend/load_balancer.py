"""
load_balancer.py
------------------
Pipeline stage 5 (Traffic Load Balancing) — the multi-tab demo centerpiece.

Keeps an in-memory record of how many active (simulated) sessions are
currently assigned to each of the 5 route options for a given
source-destination pair, and nudges new requests toward less-crowded
routes instead of always picking the single lowest-cost one. That's what
makes 4 browser tabs entering the same source/destination spread across
different routes instead of piling onto one "best" path.

No database needed — everything here resets when the server restarts,
which is fine since there are no user accounts to persist anyway.
"""

import logging
import threading

logger = logging.getLogger("qroutes.load_balancer")

# How much extra "weight" one additional session on a route adds to its
# effective cost. Higher = load balancing kicks in more aggressively.
LOAD_PENALTY_FACTOR = 0.35

_lock = threading.Lock()

# {(start_node, end_node): {route_label: session_count}}
route_load_counter = {}

# {session_id: {"start_node":.., "end_node":.., "route_label":.., "route": [...], "progress_index": 0}}
session_assignments = {}


def _pair_key(start_node, end_node):
    return (start_node, end_node)


def get_route_load(start_node, end_node):
    """Returns a plain dict {route_label: count} for a given pair —
    exactly what the frontend's 'Live Traffic Load' panel needs."""
    with _lock:
        return dict(route_load_counter.get(_pair_key(start_node, end_node), {}))


def register_session(session_id, start_node, end_node, route_label, route):
    """Marks session_id as now being on route_label for this pair, and
    increments that route's load counter."""
    with _lock:
        key = _pair_key(start_node, end_node)
        route_load_counter.setdefault(key, {})
        route_load_counter[key][route_label] = route_load_counter[key].get(route_label, 0) + 1

        session_assignments[session_id] = {
            "start_node": start_node,
            "end_node": end_node,
            "route_label": route_label,
            "route": route,
            "progress_index": 0,
        }
    logger.info("Session %s registered on '%s' for %s -> %s",
                session_id, route_label, start_node, end_node)


def release_session(session_id):
    """Removes a session's current route assignment and decrements its
    route's load counter. Call this when a session reroutes or disconnects."""
    with _lock:
        assignment = session_assignments.pop(session_id, None)
        if not assignment:
            return
        key = _pair_key(assignment["start_node"], assignment["end_node"])
        label = assignment["route_label"]
        if key in route_load_counter and label in route_load_counter[key]:
            route_load_counter[key][label] = max(0, route_load_counter[key][label] - 1)
    logger.info("Session %s released from '%s'", session_id, assignment["route_label"])


def pick_best_route(session_id, start_node, end_node, five_routes):
    """
    Chooses which of the 5 QPSO-generated routes THIS session should get,
    factoring in current load on each route — not just raw QPSO cost.

    combined_score = route_cost * (1 + LOAD_PENALTY_FACTOR * current_load)

    A route that's already carrying more simulated sessions looks less
    attractive even if its raw QPSO cost was the best, so new sessions
    naturally spread out across the 5 options instead of piling onto one.

    Registers the chosen route for this session and returns:
        (assigned_route_dict, route_load_snapshot)
    """
    # If this session already had a route, release it first so it doesn't
    # double-count itself while we recompute.
    release_session(session_id)

    key = _pair_key(start_node, end_node)
    with _lock:
        current_load = dict(route_load_counter.get(key, {}))

    scored = []
    for route in five_routes:
        load = current_load.get(route["label"], 0)
        combined_score = route["cost"] * (1 + LOAD_PENALTY_FACTOR * load)
        scored.append((combined_score, route))

    scored.sort(key=lambda pair: pair[0])
    _, chosen_route = scored[0]

    register_session(session_id, start_node, end_node,
                      chosen_route["label"], chosen_route["route"])

    return chosen_route, get_route_load(start_node, end_node)


if __name__ == "__main__":
    # Simulate 4 "browser tabs" requesting the exact same source/destination
    # and confirm they don't all land on the same route.
    fake_routes = [
        {"label": "Fastest Route", "cost": 10.0, "route": [1, 2, 3]},
        {"label": "Shortest Route", "cost": 10.2, "route": [1, 4, 3]},
        {"label": "Less Traffic Route", "cost": 11.0, "route": [1, 5, 3]},
        {"label": "Less Time Route", "cost": 10.5, "route": [1, 6, 3]},
        {"label": "Balanced Route", "cost": 10.3, "route": [1, 7, 3]},
    ]

    assigned_labels = []
    for i in range(4):
        chosen, load_snapshot = pick_best_route(f"tab-{i}", start_node=1, end_node=3,
                                                 five_routes=fake_routes)
        assigned_labels.append(chosen["label"])
        print(f"tab-{i} -> {chosen['label']}   | load now: {load_snapshot}")

    print("\nDistinct routes used:", len(set(assigned_labels)))
