"""
api_routes.py
--------------
Pipeline stage 6 (Optimized Output) — the doorway the frontend talks to.

Endpoints:
  POST /get-routes          -> the 5 QPSO routes + this session's assignment
  GET  /compare-algorithms   -> QPSO vs Dijkstra vs A* on the same request
  WS   /ws/live-updates      -> live route-load + traffic-alert push

Also runs a background task that watches every active session for newly
congested road segments up to ~1km ahead on their current route, and
pushes an automatic reroute over the WebSocket when that happens.
"""

import asyncio
import logging

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

import graph_builder
import qpso_optimizer
import baseline_algorithms
import load_balancer
import database
import traffic_simulator
from schemas import (
    GetRoutesRequest, GetRoutesResponse, RouteOption,
    CompareAlgorithmsResponse, CompareAlgorithmsResult,
)

logger = logging.getLogger("qroutes.api_routes")

router = APIRouter()

# Populated by main.py at startup — the one shared, live road graph.
STATE = {"graph": None}

# Roughly how far "ahead" (metres) we check for new congestion before
# triggering an automatic reroute alert.
REROUTE_LOOKAHEAD_METERS = 1000

_connected_clients: list[WebSocket] = []


def _route_to_coordinates(graph, route):
    return [[graph.nodes[n]["y"], graph.nodes[n]["x"]] for n in route]  # [lat, lng]


async def broadcast_update(message: dict):
    """Sends a JSON message to every currently-connected WebSocket client,
    silently dropping any that have disconnected."""
    stale = []
    for ws in _connected_clients:
        try:
            await ws.send_json(message)
        except Exception:  # noqa: BLE001
            stale.append(ws)
    for ws in stale:
        if ws in _connected_clients:
            _connected_clients.remove(ws)


# --------------------------------------------------------------------------
# Step 11 — main routing endpoint
# --------------------------------------------------------------------------

@router.post("/get-routes", response_model=GetRoutesResponse)
async def get_routes(payload: GetRoutesRequest):
    graph = STATE["graph"]

    start_node = _nearest_node(graph, payload.start_lat, payload.start_lng)
    end_node = _nearest_node(graph, payload.end_lat, payload.end_lng)

    vehicle_graph = graph_builder.filter_graph_for_vehicle(graph, payload.vehicle_type)

    five_routes = qpso_optimizer.get_five_routes(vehicle_graph, start_node, end_node)

    assigned_route, route_load = load_balancer.pick_best_route(
        payload.session_id, start_node, end_node, five_routes
    )

    await broadcast_update({"type": "route_load", "data": route_load})

    response_routes = [
        RouteOption(
            label=r["label"],
            coordinates=_route_to_coordinates(vehicle_graph, r["route"]),
            time_minutes=r["time_minutes"],
            distance_km=r["distance_km"],
            congestion_level=r["congestion_level"],
        )
        for r in five_routes
    ]

    return GetRoutesResponse(
        all_routes=response_routes,
        assigned_route_label=assigned_route["label"],
        route_load=route_load,
    )


def _nearest_node(graph, lat, lng):
    """Finds the graph node closest to (lat, lng). Uses OSMnx's fast
    nearest_nodes helper when it's available (real OSM graphs); falls back
    to a simple linear scan otherwise (fine for small demo graphs)."""
    try:
        import osmnx as ox
        return ox.distance.nearest_nodes(graph, X=lng, Y=lat)
    except Exception:  # noqa: BLE001 — osmnx missing, or not an OSM-shaped graph
        best_node, best_dist = None, float("inf")
        for node, data in graph.nodes(data=True):
            d = (data["x"] - lng) ** 2 + (data["y"] - lat) ** 2
            if d < best_dist:
                best_dist = d
                best_node = node
        return best_node


# --------------------------------------------------------------------------
# Step 14 — algorithm comparison endpoint
# --------------------------------------------------------------------------

@router.get("/compare-algorithms", response_model=CompareAlgorithmsResponse)
async def compare_algorithms(start_lat: float, start_lng: float, end_lat: float, end_lng: float):
    graph = STATE["graph"]
    start_node = _nearest_node(graph, start_lat, start_lng)
    end_node = _nearest_node(graph, end_lat, end_lng)

    dijkstra = baseline_algorithms.dijkstra_route(graph, start_node, end_node)
    astar = baseline_algorithms.astar_route(graph, start_node, end_node)
    qpso = qpso_optimizer.run_qpso(
        graph, start_node, end_node,
        weights=next(c["weights"] for c in qpso_optimizer.ROUTE_CONFIGS if c["label"] == "Balanced Route"),
    )

    results = []
    for name, outcome in [("Dijkstra", dijkstra), ("A*", astar), ("QPSO (Balanced)", qpso)]:
        stats = qpso_optimizer.route_stats(graph, outcome["route"])
        results.append(CompareAlgorithmsResult(
            algorithm=name,
            total_time_minutes=round(stats["time_minutes"], 2),
            total_distance_km=round(stats["distance_km"], 3),
            computation_time_ms=round(outcome["computation_time_ms"], 3),
        ))

    return CompareAlgorithmsResponse(results=results)


# --------------------------------------------------------------------------
# Step 12 — WebSocket for live route-load + traffic alerts
# --------------------------------------------------------------------------

@router.websocket("/ws/live-updates")
async def live_updates(websocket: WebSocket):
    await websocket.accept()
    _connected_clients.append(websocket)
    try:
        await websocket.send_json({"type": "route_load", "data": load_balancer.route_load_counter})
        while True:
            # We don't need anything FROM the client — just keep the
            # connection open so the server can push updates to it.
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        if websocket in _connected_clients:
            _connected_clients.remove(websocket)


# --------------------------------------------------------------------------
# Step 13 — background congestion watcher / auto-reroute
# --------------------------------------------------------------------------

async def check_for_reroutes():
    """
    Runs forever in the background: every 6 seconds, checks whether any
    active session now has heavy congestion within ~1km ahead on its
    current route, and if so, re-runs QPSO and pushes a traffic_alert with
    the new route over the WebSocket.

    Position is simulated with a simple per-session progress index rather
    than real GPS input, since there's no live location feed for a
    hackathon demo.
    """
    while True:
        await asyncio.sleep(6)
        graph = STATE["graph"]
        if graph is None:
            continue

        for session_id, assignment in list(load_balancer.session_assignments.items()):
            route = assignment["route"]
            progress = assignment.get("progress_index", 0)
            remaining = route[progress:]
            if len(remaining) < 2:
                continue

            if _has_heavy_congestion_ahead(graph, remaining, REROUTE_LOOKAHEAD_METERS):
                try:
                    new_outcome = qpso_optimizer.run_qpso(
                        graph, remaining[0], route[-1],
                        weights={"time": 1.0, "distance": 0.0, "congestion": 0.0},
                    )
                except Exception:  # noqa: BLE001 — no path found, skip this cycle
                    continue

                if new_outcome["route"] != remaining:
                    assignment["route"] = route[:progress] + new_outcome["route"]
                    await broadcast_update({
                        "type": "traffic_alert",
                        "session_id": session_id,
                        "message": "Heavy traffic ahead — rerouting...",
                        "new_route": _route_to_coordinates(graph, new_outcome["route"]),
                    })
                    logger.info("Session %s auto-rerouted due to congestion.", session_id)


def _has_heavy_congestion_ahead(graph, remaining_route, lookahead_meters):
    covered = 0.0
    for u, v in zip(remaining_route[:-1], remaining_route[1:]):
        edge_data = min(graph.get_edge_data(u, v).values(), key=lambda d: d.get("weight_time", float("inf")))
        if edge_data.get("congestion_multiplier", 1.0) >= 2.0:
            return True
        covered += edge_data.get("length", 0.0)
        if covered >= lookahead_meters:
            break
    return False


# --------------------------------------------------------------------------
# Traffic timer callback -> broadcast + DB snapshot
# --------------------------------------------------------------------------

def on_traffic_update(congested_edges):
    """Called by traffic_simulator's TrafficTimer every time traffic
    changes. Schedules a DB snapshot; the WebSocket broadcast for big
    swings is handled inside check_for_reroutes()/get_routes for load,
    but we also ping a general traffic_alert if a large chunk of the
    graph just changed."""
    try:
        database.save_traffic_snapshot(len(congested_edges))
    except Exception:  # noqa: BLE001
        logger.exception("Could not save traffic snapshot to database.")
