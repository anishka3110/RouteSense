"""
database.py
------------
Lightweight persistence layer. No user/account tables — there's no login,
so nothing needs to be stored per-account. This only keeps:

  road_network_snapshots  -> a record every time a road graph is (re)built
  traffic_snapshots       -> a record every time traffic is simulated

Tries PostgreSQL + PostGIS first (real production setup — where road
geometry would be stored as PostGIS Geometry("LINESTRING") columns instead
of plain floats). If DATABASE_URL isn't set or the connection fails, it
falls back automatically to a local SQLite file so the app still runs on a
laptop with nothing installed.
"""

import os
import logging
import datetime

from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker

logger = logging.getLogger("qroutes.database")

Base = declarative_base()


class RoadNetworkSnapshot(Base):
    __tablename__ = "road_network_snapshots"

    id = Column(Integer, primary_key=True, autoincrement=True)
    area_name = Column(String, nullable=False)
    node_count = Column(Integer, nullable=False)
    edge_count = Column(Integer, nullable=False)
    saved_at = Column(DateTime, default=datetime.datetime.utcnow)

    # In production with PostGIS enabled, this table would also carry a
    # `geometry = Column(Geometry("LINESTRING"))` column (from
    # geoalchemy2.Geometry) storing the actual road-network shape, instead
    # of relying purely on the separately-cached road_network.graphml file.


class TrafficSnapshot(Base):
    __tablename__ = "traffic_snapshots"

    id = Column(Integer, primary_key=True, autoincrement=True)
    congested_edge_count = Column(Integer, nullable=False)
    snapshot_time = Column(DateTime, default=datetime.datetime.utcnow)


def _build_engine():
    database_url = os.environ.get("DATABASE_URL")
    if database_url:
        try:
            engine = create_engine(database_url, pool_pre_ping=True)
            with engine.connect():
                pass  # just confirming the connection works
            logger.info("Connected to PostgreSQL/PostGIS at DATABASE_URL.")
            return engine
        except Exception as exc:  # noqa: BLE001
            logger.warning("Could not connect to DATABASE_URL (%s). "
                            "Falling back to SQLite — PostGIS not available.", exc)
    else:
        logger.warning("DATABASE_URL not set. Falling back to SQLite — PostGIS not available.")

    return create_engine("sqlite:///qroutes.db")


engine = _build_engine()
Base.metadata.create_all(engine)
SessionLocal = sessionmaker(bind=engine)


def save_road_network_snapshot(area_name, node_count, edge_count):
    with SessionLocal() as db:
        db.add(RoadNetworkSnapshot(area_name=area_name, node_count=node_count, edge_count=edge_count))
        db.commit()


def save_traffic_snapshot(congested_edge_count):
    with SessionLocal() as db:
        db.add(TrafficSnapshot(congested_edge_count=congested_edge_count))
        db.commit()
