"""
schemas.py
-----------
Pydantic request/response models shared by the API endpoints.
Kept in one file so the request/response "shape" is easy to find and edit.
"""

from typing import List, Optional
from pydantic import BaseModel, Field


class GetRoutesRequest(BaseModel):
    session_id: str = Field(..., description="Random client-generated ID, one per browser tab.")
    start_lat: float
    start_lng: float
    end_lat: float
    end_lng: float
    vehicle_type: str = Field(..., description="car | bus | bike | cycle | walking")


class RouteOption(BaseModel):
    label: str
    coordinates: List[List[float]]  # [[lat, lng], ...]
    time_minutes: float
    distance_km: float
    congestion_level: str


class GetRoutesResponse(BaseModel):
    all_routes: List[RouteOption]
    assigned_route_label: str
    route_load: dict


class CompareAlgorithmsResult(BaseModel):
    algorithm: str
    total_time_minutes: float
    total_distance_km: float
    computation_time_ms: float


class CompareAlgorithmsResponse(BaseModel):
    results: List[CompareAlgorithmsResult]
