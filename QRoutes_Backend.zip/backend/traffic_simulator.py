"""
traffic_simulator.py
---------------------
Pipeline stage 1 (Traffic & Road Data) — the "live" part.

There's no real traffic feed available for this hackathon demo, so this
module fakes one: every so often it randomly jams up a slice of roads and
clears others, similar to how a SUMO-style traffic simulation behaves. The
rest of the system (QPSO, baselines, alerts) just reacts to whatever
congestion_multiplier values are currently on the graph — it doesn't know
or care that they're simulated.
"""

import random
import threading
import logging

from graph_builder import refresh_graph_weights

logger = logging.getLogger("qroutes.traffic_simulator")

CONGESTED_FRACTION_RANGE = (0.10, 0.15)  # 10-15% of edges get jammed
CONGESTION_MULTIPLIER_RANGE = (2.0, 4.0)  # "heavily congested"


def apply_dynamic_traffic(graph):
    """
    Randomly congests 10-15% of edges (multiplier 2.0-4.0) and resets every
    other edge to normal (1.0), then refreshes weight_time so the change
    takes effect immediately. Returns the list of newly congested edges as
    (u, v, key) tuples.
    """
    all_edges = list(graph.edges(keys=True))
    if not all_edges:
        return []

    fraction = random.uniform(*CONGESTED_FRACTION_RANGE)
    sample_size = max(1, int(len(all_edges) * fraction))
    congested_edges = random.sample(all_edges, sample_size)
    congested_set = set(congested_edges)

    for edge in all_edges:
        u, v, key = edge
        if edge in congested_set:
            graph.edges[u, v, key]["congestion_multiplier"] = random.uniform(
                *CONGESTION_MULTIPLIER_RANGE
            )
        else:
            graph.edges[u, v, key]["congestion_multiplier"] = 1.0

    refresh_graph_weights(graph)
    logger.info("Traffic updated: %s/%s edges now congested.",
                len(congested_edges), len(all_edges))
    return congested_edges


class TrafficTimer:
    """
    Runs apply_dynamic_traffic(graph) automatically every interval_seconds,
    in a background thread, until stop() is called. Using a thread (rather
    than requiring asyncio) keeps this usable from both sync scripts and
    FastAPI's startup event.
    """

    def __init__(self, graph, interval_seconds=15, on_update=None):
        self.graph = graph
        self.interval_seconds = interval_seconds
        self.on_update = on_update  # optional callback(congested_edges)
        self._stop_event = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        while not self._stop_event.wait(self.interval_seconds):
            congested = apply_dynamic_traffic(self.graph)
            if self.on_update:
                try:
                    self.on_update(congested)
                except Exception:  # noqa: BLE001
                    logger.exception("on_update callback failed")

    def start(self):
        self._thread.start()
        logger.info("Traffic timer started (every %ss).", self.interval_seconds)

    def stop(self):
        self._stop_event.set()


def start_traffic_timer(graph, interval_seconds=15, on_update=None):
    """Convenience wrapper: creates and starts a TrafficTimer, returns it
    so the caller can .stop() it later (e.g. on FastAPI shutdown)."""
    timer = TrafficTimer(graph, interval_seconds=interval_seconds, on_update=on_update)
    timer.start()
    return timer


if __name__ == "__main__":
    from graph_builder import download_road_network, prepare_graph_weights

    g = prepare_graph_weights(download_road_network(12.9716, 77.5946))
    first = set(apply_dynamic_traffic(g))
    second = set(apply_dynamic_traffic(g))
    print("First congestion set size:", len(first))
    print("Second congestion set size:", len(second))
    print("Sets differ:", first != second)
